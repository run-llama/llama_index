"""Graph stores."""

from llama_index.core.graph_stores.simple import SimpleGraphStore

__all__ = [
    "SimpleGraphStore",
]
