"""ReAct agent.

Simple wrapper around AgentRunner + ReActAgentWorker.

For the legacy implementation see:
```python
from llama_index.core.agent.legacy.react.base import ReActAgent
```

"""
