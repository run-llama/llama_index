# for backwards compatibility
from llama_index.core.service_context import ServiceContext

__all__ = [
    "ServiceContext",
]
