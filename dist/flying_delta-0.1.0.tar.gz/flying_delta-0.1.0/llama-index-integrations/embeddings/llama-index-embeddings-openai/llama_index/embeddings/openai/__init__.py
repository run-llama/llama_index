from llama_index.embeddings.openai.base import OpenAIEmbedding

__all__ = ["OpenAIEmbedding"]
