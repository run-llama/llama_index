from llama_index.embeddings.clip.base import ClipEmbedding

__all__ = ["ClipEmbedding"]
